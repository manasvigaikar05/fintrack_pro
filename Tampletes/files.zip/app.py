from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import datetime

app = Flask(__name__)
DB = "fintrack.db"

CATEGORIES = {
    "expense": ["🍔 Food", "🚗 Transport", "🏠 Housing", "💊 Health",
                "🎮 Entertainment", "👗 Shopping", "📚 Education", "⚡ Utilities", "🔧 Other"],
    "income":  ["💼 Salary", "💻 Freelance", "📈 Investment", "🎁 Gift", "💰 Other"],
}

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL,
            description TEXT,
            date TEXT NOT NULL
        )""")
        conn.commit()

@app.route("/")
def dashboard():
    conn = get_db()
    month = datetime.date.today().strftime("%Y-%m")
    rows = conn.execute("SELECT * FROM transactions WHERE date LIKE ? ORDER BY date DESC", (f"{month}%",)).fetchall()
    all_rows = conn.execute("SELECT * FROM transactions ORDER BY date DESC LIMIT 6").fetchall()
    income  = sum(r["amount"] for r in rows if r["type"] == "income")
    expense = sum(r["amount"] for r in rows if r["type"] == "expense")
    balance = income - expense
    cat_data = {}
    for r in rows:
        if r["type"] == "expense":
            cat_data[r["category"]] = cat_data.get(r["category"], 0) + r["amount"]
    conn.close()
    return render_template("index.html",
        income=income, expense=expense, balance=balance,
        recent=all_rows, cat_data=cat_data,
        month=datetime.date.today().strftime("%B %Y"))

@app.route("/add", methods=["GET", "POST"])
def add():
    msg = ""
    if request.method == "POST":
        type_   = request.form.get("type", "expense")
        category = request.form.get("category")
        amount   = request.form.get("amount")
        desc     = request.form.get("description", "")
        date     = request.form.get("date", datetime.date.today().isoformat())
        try:
            amt = float(amount)
            if amt <= 0: raise ValueError
            with get_db() as conn:
                conn.execute("INSERT INTO transactions (type,category,amount,description,date) VALUES (?,?,?,?,?)",
                             (type_, category, amt, desc, date))
                conn.commit()
            msg = "success"
            return redirect(url_for("dashboard"))
        except:
            msg = "Please enter a valid amount."
    return render_template("add.html", categories=CATEGORIES, msg=msg,
                           today=datetime.date.today().isoformat())

@app.route("/history")
def history():
    conn = get_db()
    rows = conn.execute("SELECT * FROM transactions ORDER BY date DESC").fetchall()
    conn.close()
    return render_template("history.html", transactions=rows)

@app.route("/delete/<int:tid>")
def delete(tid):
    with get_db() as conn:
        conn.execute("DELETE FROM transactions WHERE id=?", (tid,))
        conn.commit()
    return redirect(url_for("history"))

@app.route("/analytics")
def analytics():
    conn = get_db()
    rows = conn.execute("SELECT * FROM transactions").fetchall()
    income  = sum(r["amount"] for r in rows if r["type"] == "income")
    expense = sum(r["amount"] for r in rows if r["type"] == "expense")
    cat_data = {}
    for r in rows:
        if r["type"] == "expense":
            cat_data[r["category"]] = cat_data.get(r["category"], 0) + r["amount"]
    conn.close()
    return render_template("analytics.html", income=income, expense=expense, cat_data=cat_data)

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
